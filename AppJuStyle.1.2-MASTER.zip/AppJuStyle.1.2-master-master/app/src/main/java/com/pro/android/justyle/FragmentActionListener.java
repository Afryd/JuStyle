package com.pro.android.justyle;

public interface FragmentActionListener {

    String FRAGMENT_SELECTED = "FRAGMENT_SELECTED";

    void onWardrobeFragmentClicked();
    void onMarketplaceFragmentClicked();

}